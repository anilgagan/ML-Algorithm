#Through this Code we can Compress multple image simultaneously 
#This code is runing
#Example : Through this code we can convert image size of 80 MB to 20 MB.